from flask import Flask, render_template, request
import PyPDF2
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

skills_list = ['Python', 'Java', 'C++', 'Machine Learning', 'Flask', 'Django', 'SQL', 'HTML', 'CSS']

def extract_text_from_pdf(pdf_path):
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        text = ''
        for page in reader.pages:
            text += page.extract_text()
    return text

def analyze_skills(resume_text):
    found_skills = [skill for skill in skills_list if skill.lower() in resume_text.lower()]
    return found_skills

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'resume' not in request.files:
        return "No file uploaded", 400

    file = request.files['resume']
    if file.filename == '':
        return "No selected file", 400

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    text = extract_text_from_pdf(filepath)
    skills = analyze_skills(text)

    return render_template('result.html', text=text, skills=skills)

if __name__ == '__main__':
    app.run(debug=True)
